import React, { useEffect, useRef, useState } from 'react';
import { ChatMessage } from '../types';
import { Bot, User, Loader2, ChevronRight, BrainCircuit, Terminal } from 'lucide-react';

interface ChatInterfaceProps {
  messages: ChatMessage[];
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages }) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [expandedThoughts, setExpandedThoughts] = useState<Record<string, boolean>>({});

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const toggleThoughts = (id: string) => {
    setExpandedThoughts(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950 rounded-xl border border-zinc-800 shadow-xl overflow-hidden font-sans">
      <div className="p-4 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <BrainCircuit className="w-5 h-5 text-red-500" />
          <span className="font-bold text-white tracking-tight">Agent Reasoning Hub</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-red-600 rounded-full animate-pulse shadow-[0_0_8px_rgba(220,38,38,0.8)]" />
          <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Active State</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-zinc-700">
            <Terminal className="w-12 h-12 mb-2 text-zinc-800" />
            <p className="text-sm font-bold">System ready. Waiting for .c module.</p>
          </div>
        )}
        
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[90%] rounded-xl p-3 shadow-md transition-all ${
                msg.role === 'user'
                  ? 'bg-red-700 text-white border border-red-600'
                  : msg.type === 'thought' 
                    ? 'bg-zinc-900 text-zinc-200 border border-red-900/30'
                    : 'bg-zinc-800 text-white border border-zinc-700'
              }`}
            >
              <div className={`flex items-center space-x-2 mb-2 opacity-70 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                {msg.role === 'user' ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  {msg.type === 'thought' ? 'ToT Reasoning' : msg.role}
                </span>
              </div>
              
              <div className="text-[14px] whitespace-pre-wrap leading-relaxed">
                {msg.type === 'loader' ? (
                  <div className="flex items-center space-x-3">
                    <Loader2 className="w-4 h-4 animate-spin text-red-500" />
                    <span className="italic text-zinc-400">{msg.content}</span>
                  </div>
                ) : (
                  msg.content
                )}
              </div>

              {msg.thoughts && msg.thoughts.length > 0 && (
                <div className="mt-3 pt-3 border-t border-zinc-700/50">
                  <button 
                    onClick={() => toggleThoughts(msg.id)}
                    className="flex items-center space-x-1 text-[10px] font-bold uppercase text-red-500 hover:text-red-400"
                  >
                    <ChevronRight className={`w-3 h-3 transition-transform ${expandedThoughts[msg.id] ? 'rotate-90' : ''}`} />
                    <span>View Logic Fragments ({msg.thoughts.length})</span>
                  </button>
                  
                  {expandedThoughts[msg.id] && (
                    <div className="mt-2 space-y-2 bg-black/30 rounded-lg p-2 border border-zinc-800">
                      {msg.thoughts.map((thought, idx) => (
                        <div key={idx} className="flex gap-2 text-[12px] leading-tight text-zinc-400">
                          <span className="text-red-800 font-mono font-bold">[{idx+1}]</span>
                          <span>{thought}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
};

export default ChatInterface;