import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ExecutionReport, TestCase, TestResult } from '../types';
import { Activity, GitBranch, FileCode, CheckCircle, Layers, ChevronRight, Loader2 } from 'lucide-react';

interface MetricsDashboardProps {
  report: ExecutionReport | null;
  testCases: TestCase[];
  stepsUsed: number;
  isExecuting: boolean;
}

// Helper to visualize non-printable chars
const formatContent = (text: string | undefined | null) => {
  if (text === undefined || text === null) return <span className="text-zinc-700 italic">No output</span>;
  if (text === '') return <span className="text-zinc-600 italic">Empty</span>;
  const clipped = text.length > 400 ? text.slice(0, 400) + '…' : text;

  if (/^[\x20-\x7E]*$/.test(clipped)) return clipped;

  return (
    <span>
      {clipped.split('').map((char, i) => {
        const code = char.charCodeAt(0);
        if (code < 32 || code > 126) {
          if (char === '\n') return <span key={i} className="text-zinc-500 select-none opacity-50">↵</span>;
          if (char === '\t') return <span key={i} className="text-zinc-500 select-none opacity-50">⇥</span>;
          if (char === '…') return char;
          return (
            <span key={i} className="text-red-400 text-[10px] font-mono bg-red-950/50 px-0.5 rounded border border-red-900/30 mx-0.5">
              \x{code.toString(16).padStart(2, '0').toUpperCase()}
            </span>
          );
        }
        return char;
      })}
    </span>
  );
};

const Badge: React.FC<{ tone: 'good' | 'bad' | 'neutral'; children: React.ReactNode }> = ({ tone, children }) => (
  <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold border whitespace-nowrap ${
    tone === 'good' ? 'bg-green-950 text-green-400 border-green-900' :
    tone === 'bad' ? 'bg-red-950 text-red-400 border-red-900' :
    'bg-zinc-900 text-zinc-400 border-zinc-800'
  }`}>
    {children}
  </span>
);

const endingLabel = (r: TestResult['original']) => {
  if (r.ending === 'exit') return `exit ${r.exitCode}`;
  if (r.ending === 'timeout') return 'timeout';
  if (r.ending === 'output_limit') return 'output limit';
  return r.ending === 'abort' ? 'abort' : `crash ${r.signal ?? ''}`;
};

const MetricsDashboard: React.FC<MetricsDashboardProps> = ({ report, testCases, stepsUsed, isExecuting }) => {
  const hasData = testCases.length > 0;

  if (!report && !hasData) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-zinc-950 rounded-xl border border-zinc-800 text-zinc-700 shadow-xl p-8">
        <Layers className="w-12 h-12 mb-4 text-zinc-900" />
        <p className="text-sm font-bold uppercase tracking-widest">Observability Deck</p>
        <p className="text-[12px] mt-1">Coverage appears here after the tests are compiled and run.</p>
      </div>
    );
  }

  const oc = report?.original.coverage;
  const opt = report?.optimized;
  const pc = opt?.compiled ? opt.coverage : null;
  const resultsById = new Map((report?.results ?? []).map(r => [r.id, r]));

  const chartData = [
    { name: 'Line Cov', Original: oc?.lineCoverage ?? 0, ...(pc ? { Optimized: pc.lineCoverage } : {}) },
    { name: 'Branch Cov', Original: oc?.branchCoverage ?? 0, ...(pc ? { Optimized: pc.branchCoverage } : {}) },
  ];

  const s = report?.summary;
  const behaviourVal = !report ? '--' : !opt ? 'n/a' : !opt.compiled ? 'No build' : `${s!.sameBehaviour}/${s!.tests}`;
  const behaviourSub = !report
    ? 'Pending...'
    : `Predicted right ${s!.predictionsCorrect}/${s!.predictionsChecked}`;

  const kpis = [
    { label: 'Tests', val: testCases.length, sub: `k-Steps: ${stepsUsed || '…'}`, icon: Activity, color: 'text-red-500' },
    { label: 'Line Cov', val: oc ? `${oc.lineCoverage}%` : '--', sub: oc ? `${oc.linesCovered}/${oc.linesTotal} lines` : 'Pending...', icon: FileCode, color: 'text-orange-500' },
    { label: 'Branch Cov', val: oc ? `${oc.branchCoverage}%` : '--', sub: oc ? `${oc.branchesTaken}/${oc.branchesTotal} branches` : 'Pending...', icon: GitBranch, color: 'text-blue-500' },
    { label: 'Same Behaviour', val: behaviourVal, sub: behaviourSub, icon: CheckCircle, color: opt && !opt.compiled ? 'text-red-500' : 'text-green-500' },
  ];

  return (
    <div className="space-y-4 h-full flex flex-col font-sans">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 flex-shrink-0">
        {kpis.map((kpi, i) => (
          <div key={i} className="bg-zinc-900 p-4 rounded-xl border border-zinc-800 shadow-sm transition-all hover:border-zinc-700">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] uppercase font-bold text-zinc-500 tracking-widest">{kpi.label}</span>
              <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
            </div>
            <div className={`text-2xl font-bold ${kpi.color} tracking-tight`}>{kpi.val}</div>
            <div className="text-[10px] text-zinc-500 font-mono mt-1 font-bold">{kpi.sub}</div>
          </div>
        ))}
      </div>

      <div className="flex gap-4 flex-1 min-h-0">
        <div className="bg-zinc-950 p-5 rounded-xl border border-zinc-800 shadow-xl w-[35%] flex-shrink-0 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Coverage</h3>
            <span className="text-[10px] font-mono text-zinc-600">Measured with gcov</span>
          </div>
          <div className="flex-1">
             {report ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} layout="vertical" margin={{ left: -10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272a" horizontal={true} vertical={false} />
                    <XAxis type="number" domain={[0, 100]} hide />
                    <YAxis dataKey="name" type="category" stroke="#71717a" fontSize={10} width={60} axisLine={false} tickLine={false} />
                    <Tooltip 
                      cursor={{fill: '#18181b'}} 
                      formatter={(v: number) => `${v}%`}
                      contentStyle={{ backgroundColor: '#09090b', borderRadius: '8px', border: '1px solid #27272a', color: '#fff' }} 
                    />
                    <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px', fontSize: '10px', fontWeight: 'bold' }} />
                    <Bar dataKey="Original" fill="#ef4444" radius={[0, 4, 4, 0]} barSize={12} />
                    {pc && <Bar dataKey="Optimized" fill="#52525b" radius={[0, 4, 4, 0]} barSize={12} />}
                  </BarChart>
                </ResponsiveContainer>
             ) : (
                <div className="h-full flex flex-col items-center justify-center text-zinc-600">
                   {isExecuting && <Loader2 className="w-8 h-8 animate-spin mb-2 text-red-800" />}
                   <span className="text-xs font-bold">{isExecuting ? 'Compiling and running tests…' : 'Not measured yet'}</span>
                </div>
             )}
          </div>
          {opt && !opt.compiled && (
            <p className="text-[10px] text-red-400 mt-3 leading-snug">The optimized code does not compile. The compiler message is in the exported report.</p>
          )}
        </div>

        <div className="bg-zinc-950 p-5 rounded-xl border border-zinc-800 shadow-xl flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between mb-4 flex-shrink-0">
            <h3 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
              {report ? 'Test Results' : 'Live Test Generation Feed'}
            </h3>
            {report && (
              <span className="text-[10px] font-mono text-zinc-600">
                {s!.aborts} aborts, {s!.crashes} crashes, {s!.timeouts} timeouts
              </span>
            )}
          </div>
          <div className="flex-1 overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-zinc-950 z-10">
                <tr className="border-b border-zinc-800 text-[10px] font-bold text-zinc-600 uppercase tracking-widest">
                  <th className="py-2 px-2 w-[10%]">Type</th>
                  <th className="py-2 px-2 w-[50%]">Input / Output</th>
                  <th className="py-2 px-2 w-[40%] text-right">Result</th>
                </tr>
              </thead>
              <tbody className="text-[12px]">
                {testCases.map((tc) => {
                  const r = resultsById.get(tc.id);
                  return (
                    <tr key={tc.id} className="border-b border-zinc-900 hover:bg-zinc-900/50 transition-colors group">
                      <td className="py-3 px-2 align-top">
                        <span className={`px-2 py-0.5 rounded-md text-[9px] font-bold uppercase ${
                          tc.category === 'valid' ? 'bg-green-950 text-green-400 border border-green-900' :
                          tc.category === 'boundary' ? 'bg-orange-950 text-orange-400 border border-orange-900' :
                          'bg-red-950 text-red-400 border border-red-900'
                        }`}>
                          {tc.category}
                        </span>
                        {tc.step && <div className="text-[9px] text-zinc-600 font-mono mt-1">k={tc.step}</div>}
                      </td>
                      <td className="py-3 px-2 align-top">
                        <div className="space-y-2">
                           <div className="flex items-start gap-2">
                             <span className="text-[10px] font-bold text-zinc-500 w-16 pt-0.5 flex-shrink-0">IN:</span>
                             <code className="bg-zinc-900 px-1.5 py-0.5 rounded text-zinc-200 font-mono text-[11px] border border-zinc-800 break-all">
                               {formatContent(tc.input)}
                             </code>
                           </div>
                           <div className="flex items-start gap-2">
                             <span className="text-[10px] font-bold text-zinc-500 w-16 pt-0.5 flex-shrink-0">PREDICTED:</span>
                             <code className="bg-zinc-950 px-1.5 py-0.5 rounded text-zinc-400 font-mono text-[11px] border border-zinc-800/50 break-all">
                               {formatContent(tc.expectedOutput)}
                             </code>
                           </div>
                           {r && (
                             <div className="flex items-start gap-2">
                               <span className="text-[10px] font-bold text-red-500 w-16 pt-0.5 flex-shrink-0">ACTUAL:</span>
                               <code className="bg-zinc-950 px-1.5 py-0.5 rounded text-red-400 font-mono text-[11px] border border-zinc-800/50 break-all">
                                 {formatContent(r.original.stdout)}
                               </code>
                             </div>
                           )}
                        </div>
                        <div className="mt-2 text-[10px] text-zinc-600 italic max-w-md">
                          {tc.description}
                        </div>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <div className="flex flex-col items-end gap-2">
                          {r ? (
                            <div className="flex flex-wrap justify-end gap-1">
                              <Badge tone={r.original.ending === 'exit' ? 'neutral' : 'bad'}>{endingLabel(r.original)}</Badge>
                              {r.predictionCorrect !== null && (
                                <Badge tone={r.predictionCorrect ? 'good' : 'bad'}>{r.predictionCorrect ? 'Prediction right' : 'Prediction wrong'}</Badge>
                              )}
                              {r.sameBehaviour !== null && (
                                <Badge tone={r.sameBehaviour ? 'good' : 'bad'}>{r.sameBehaviour ? 'Optimized: same' : 'Optimized: different'}</Badge>
                              )}
                            </div>
                          ) : (
                            <Badge tone="neutral">{isExecuting ? 'Running…' : 'Not run yet'}</Badge>
                          )}
                          {tc.reasoningPath && (
                            <div className="flex flex-wrap justify-end gap-1">
                              {tc.reasoningPath.slice(0, 3).map((step, idx) => (
                                <span key={idx} className="bg-zinc-900 text-[9px] text-zinc-400 px-1.5 py-0.5 rounded flex items-center border border-zinc-800">
                                  {idx > 0 && <ChevronRight className="w-2 h-2 mr-0.5 text-red-900" />}
                                  {step}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetricsDashboard;
