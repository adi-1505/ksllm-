
import React from 'react';
import { Copy, Hash } from 'lucide-react';

interface CodeViewerProps {
  originalCode: string;
  optimizedCode: string;
}

const CodeViewer: React.FC<CodeViewerProps> = ({ originalCode, optimizedCode }) => {
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getLineCount = (code: string) => {
    if (!code) return 0;
    return code.trim().split('\n').length;
  };

  const originalLines = getLineCount(originalCode);
  const optimizedLines = getLineCount(optimizedCode);

  return (
    <div className="grid grid-cols-2 gap-4 h-full">
      <div className="flex flex-col h-full bg-zinc-950 rounded-xl border border-zinc-800 shadow-xl overflow-hidden">
        <div className="p-2 bg-zinc-900 border-b border-zinc-800 flex justify-between items-center">
          <div className="flex items-center gap-2 px-2">
            <span className="text-[10px] font-mono text-zinc-500 font-bold uppercase tracking-widest">original.c</span>
            {originalCode && (
              <div className="flex items-center gap-1 bg-black px-1.5 py-0.5 rounded border border-zinc-800">
                <Hash className="w-2.5 h-2.5 text-zinc-600" />
                <span className="text-[9px] font-mono text-zinc-400 font-bold">{originalLines} lines</span>
              </div>
            )}
          </div>
          <button 
            onClick={() => handleCopy(originalCode)}
            className="p-1 text-zinc-500 hover:text-white transition-colors" title="Copy"
          >
            <Copy className="w-3 h-3" />
          </button>
        </div>
        <pre className="flex-1 p-4 text-[13px] font-mono text-zinc-300 bg-black overflow-auto whitespace-pre">
          {originalCode || "// Waiting for file upload..."}
        </pre>
      </div>

      <div className="flex flex-col h-full bg-zinc-950 rounded-xl border border-red-900/30 shadow-xl overflow-hidden">
        <div className="p-2 bg-zinc-900 border-b border-zinc-800 flex justify-between items-center">
          <div className="flex items-center gap-2 px-2">
            <span className="text-[10px] font-mono text-red-500 font-bold uppercase tracking-widest">optimized.c</span>
            {optimizedCode && (
              <div className="flex items-center gap-1 bg-black px-1.5 py-0.5 rounded border border-red-900/40">
                <Hash className="w-2.5 h-2.5 text-red-900" />
                <span className="text-[9px] font-mono text-red-400 font-bold">{optimizedLines} lines</span>
              </div>
            )}
          </div>
          <button 
            onClick={() => handleCopy(optimizedCode)}
            className="p-1 text-zinc-500 hover:text-white transition-colors" title="Copy"
          >
            <Copy className="w-3 h-3" />
          </button>
        </div>
        <pre className="flex-1 p-4 text-[13px] font-mono text-zinc-300 bg-black overflow-auto whitespace-pre">
          {optimizedCode || "// Waiting for optimizer agent..."}
        </pre>
      </div>
    </div>
  );
};

export default CodeViewer;
