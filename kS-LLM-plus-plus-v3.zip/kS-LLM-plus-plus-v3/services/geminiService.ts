import { GoogleGenAI, Type, Schema } from "@google/genai";
import { TestCase, OptimizationResult } from "../types";

// Settings recorded in every report, so experiments can be reproduced.
export const PIPELINE_CONFIG = {
  optimizerModel: "gemini-3-pro-preview",
  optimizerTemperature: 0.1,
  optimizerThinkingBudget: 4000,
  generatorModel: "gemini-3-flash-preview",
  generatorTemperature: 0.5,
};

// How inputs reach the program at execution time (see server/harness.c).
const INPUT_CONVENTION = `
    HOW INPUTS ARE FED TO THE PROGRAM:
    - The test input string is sent to the program's standard input (stdin).
    - scanf / getchar / fgets read it normally.
    - Each call to __VERIFIER_nondet_int(), __VERIFIER_nondet_char(), __VERIFIER_nondet_bool()
      (and the other __VERIFIER_nondet_* functions) reads the NEXT whitespace-separated token:
      integers as decimal numbers, char as a number or a single character, bool as 0 or 1.
    - When the input runs out, every __VERIFIER_nondet_* call returns 0.
    - So give one token per nondet call, in the order the program makes those calls.`;

const stripCodeFence = (code: string): string => {
  const m = code.trim().match(/^```[a-zA-Z]*\n([\s\S]*?)\n?```$/);
  return m ? m[1] : code;
};

const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }
  return new GoogleGenAI({ apiKey });
};

async function retryWithBackoff<T>(
  fn: () => Promise<T>, 
  retries: number = 3, 
  baseDelay: number = 2000
): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const isQuotaError = error?.status === 429 || error?.code === 429 || error?.message?.toLowerCase().includes('quota');
    if (retries > 0 && isQuotaError) {
      const delay = baseDelay * (Math.pow(2, 3 - retries));
      await new Promise(resolve => setTimeout(resolve, delay));
      return retryWithBackoff(fn, retries - 1, baseDelay);
    }
    throw error;
  }
}

export const optimizeCCode = async (code: string): Promise<OptimizationResult> => {
  const ai = getAIClient();
  
  const prompt = `
    You are an expert C Optimization Agent using Tree-of-Thoughts (ToT).
    
    CRITICAL REQUIREMENT: The optimized code MUST maintain EXACTLY the same functionality as the original. 
    Do not change behavior, side effects, or input/output requirements.
    In particular: keep every input read (scanf, __VERIFIER_nondet_*) in the same order, keep every
    printed output and return/exit value, and keep error paths (reach_error, assert, abort, exit)
    unless you are certain they can never be reached.
    The optimized code will be compiled and run on the same tests as the original, and any
    difference in output will be reported.
    
    1. PROPOSE multiple refactoring paths for the provided C code.
    2. EVALUATE each path based on:
       - Cyclomatic complexity reduction.
       - Elimination of redundant logic fragments.
       - Cache locality and memory efficiency.
       - Maintainability.
    3. SELECT the optimal path and produce the refactored code.
    4. PERFORM a rigorous self-check to ensure logical equivalence.
    
    Code to optimize:
    \`\`\`c
    ${code}
    \`\`\`
    
    Calculate the line counts carefully.
    Return JSON format.
  `;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      optimizedCode: { type: Type.STRING },
      fragmentsDetected: { type: Type.INTEGER },
      improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
      originalLineCount: { type: Type.INTEGER },
      optimizedLineCount: { type: Type.INTEGER },
      reasoningSteps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "The ToT reasoning steps taken" }
    },
    required: ["optimizedCode", "fragmentsDetected", "improvements", "originalLineCount", "optimizedLineCount", "reasoningSteps"]
  };

  return retryWithBackoff(async () => {
    const response = await ai.models.generateContent({
      model: PIPELINE_CONFIG.optimizerModel,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: PIPELINE_CONFIG.optimizerTemperature,
        thinkingConfig: { thinkingBudget: PIPELINE_CONFIG.optimizerThinkingBudget }
      }
    });
    const result = JSON.parse(response.text) as OptimizationResult;
    result.optimizedCode = stripCodeFence(result.optimizedCode || "");
    return result;
  });
};

export const generateTestCases = async (
  code: string, 
  existingInputs: string[],
  count: number = 20, 
  iteration: number = 1
): Promise<TestCase[]> => {
  const ai = getAIClient();

  // Show the model the inputs it already produced so each round explores new paths
  // (this parameter was passed in before but never used).
  const recent = existingInputs.slice(-60).map((s) => JSON.stringify(s.length > 120 ? s.slice(0, 120) + "..." : s));
  const previousInputsBlock = recent.length
    ? `
    INPUTS ALREADY GENERATED IN EARLIER STEPS (do NOT repeat these; target paths they miss):
    ${recent.join("\n    ")}
`
    : "";

  const prompt = `
    Stage: k-Step Massive Test Generation (Step ${iteration}).
    Technique: Tree-of-Thoughts exhaustive exploration of control flow.
    
    Target Code:
    \`\`\`c
    ${code}
    \`\`\`
    ${INPUT_CONVENTION}
    ${previousInputsBlock}
    CRITICAL INSTRUCTIONS FOR INPUT/OUTPUT:
    1. **Strictly Printable ASCII Inputs Only**:
       - Inputs MUST be strictly human-readable printable ASCII (codes 32-126) plus standard whitespace (newline, tab).
       - ABSOLUTELY NO null bytes (\\x00), control characters (\\x01-\\x08, \\x0B, etc), or binary garbage.
       - If you need to test boundary conditions, use strings like "0", "-1", "A", or empty string "".

    2. **Actual Calculated Output**:
       - You must ACT as a C interpreter.
       - TRACE the execution of the code with the generated input.
       - CALCULATE the EXACT stdout that would be printed.
       - If the program prints nothing, return an empty string.
       - Do not explain the output, just provide the raw output string.
    
    Task: Propose exactly ${count} new, highly unique and diverse test cases.
    
    Return JSON.
  `;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      testCases: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            input: { type: Type.STRING, description: "Clean, printable ASCII input string" },
            category: { type: Type.STRING, enum: ["valid", "boundary", "edge"] },
            description: { type: Type.STRING },
            expectedOutput: { type: Type.STRING, description: "The exact calculated stdout/stderr string from execution simulation" },
            reasoningPath: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Chain of logic to reach the branch" }
          },
          required: ["input", "category", "description", "expectedOutput", "reasoningPath"]
        }
      }
    },
    required: ["testCases"]
  };

  return retryWithBackoff(async () => {
    const response = await ai.models.generateContent({
      model: PIPELINE_CONFIG.generatorModel,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        temperature: PIPELINE_CONFIG.generatorTemperature,
      }
    });
    
    const result = JSON.parse(response.text);
    
    // Strict client-side filtering to remove "boxed" unprintable characters
    const safeTestCases = (result.testCases || []).filter((tc: any) => {
        if (!tc.input) return false;
        // Allow printable ASCII (32-126) + Tab (9) + Newline (10) + Return (13)
        // Rejects all other control codes including Null (0)
        return /^[\x20-\x7E\t\n\r]*$/.test(tc.input);
    });

    return safeTestCases.map((tc: any) => ({
      ...tc,
      id: Math.random().toString(36).substring(7),
      step: iteration
    }));
  });
};