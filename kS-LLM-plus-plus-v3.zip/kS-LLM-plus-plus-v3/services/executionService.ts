import { ExecutionReport, TestCase, ToolchainStatus } from '../types';

// Talks to the local execution server (server/index.mjs) through Vite's /api proxy.
// Nothing here estimates or simulates coverage: if the server is not running,
// the app reports that instead of showing numbers.

const SERVER_HINT = 'Start the execution server in a second terminal with: npm run server';

export const checkExecutionServer = async (): Promise<ToolchainStatus> => {
  try {
    const res = await fetch('/api/health');
    const body = await res.json();
    return {
      ok: !!body.ok,
      gcc: body.gcc ?? null,
      gcov: body.gcov ?? null,
      error: body.ok ? null : body.error || 'gcc/gcov not available on the server machine.',
    };
  } catch {
    return { ok: false, gcc: null, gcov: null, error: `Execution server not reachable. ${SERVER_HINT}` };
  }
};

export const executeTests = async (
  originalCode: string,
  optimizedCode: string,
  testCases: TestCase[],
  timeoutMs = 2000,
): Promise<ExecutionReport> => {
  let res: Response;
  try {
    res = await fetch('/api/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        originalCode,
        optimizedCode,
        timeoutMs,
        tests: testCases.map((t) => ({
          id: t.id,
          input: t.input,
          expectedOutput: t.expectedOutput,
          step: t.step,
        })),
      }),
    });
  } catch {
    throw new Error(`Execution server not reachable. ${SERVER_HINT}`);
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `Execution server error (${res.status}).`);
  return body as ExecutionReport;
};
