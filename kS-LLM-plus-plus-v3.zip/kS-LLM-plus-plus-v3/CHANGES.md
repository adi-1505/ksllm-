# Changes in v3.0 (from v2.2)

## Fixed
- **Stage II now generates tests from the optimized code** produced by Stage I. In v2.2 it was given the
  original file, so the optimized code was never used for test generation.
- **Coverage is measured, not simulated.** `utils/mockBackend.ts` (a formula with random noise) is removed.
  A local server compiles the program with `gcc --coverage`, runs every test and reads coverage from gcov.
- **Earlier inputs are sent to Stage II.** `existingInputs` was passed to `generateTestCases` but never added
  to the prompt.
- Removed labels that claimed checks which did not happen ("GCOV ENGINE", "GCOV Simulation",
  "EXEC_PATH_VERIFIED", "Real-time sim").

## Added
- Behaviour check: every test runs on both the original and the optimized program; differences are reported.
- Prediction check: Gemini's predicted output is compared with the real output.
- Coverage after each k-step.
- `server/harness.c`: supplies `__VERIFIER_nondet_*` inputs from stdin for SV-COMP benchmarks, and saves gcov
  data on abort, failed assert, crash and timeout.
- Sidebar switch for ablation runs (tests from optimized vs original code).
- Execution server status in the sidebar, and **Run Tests Again** (re-runs execution without new Gemini calls).
- **Export JSON** and `npm run measure` to re-measure a saved run.

## Prompt changes
- Stage I: also asks to keep input reads, outputs and error paths, and says the result will be executed and compared.
- Stage II: explains how inputs reach the program (stdin and `__VERIFIER_nondet_*`), and lists earlier inputs.

Models, temperatures and k-step settings are unchanged.
