
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  type?: 'text' | 'loader' | 'result_summary' | 'thought';
  thoughts?: string[];
}

export interface TestCase {
  id: string;
  input: string;
  /** Output predicted by Gemini (not executed). Checked against the real output after execution. */
  expectedOutput?: string;
  category: 'valid' | 'boundary' | 'edge';
  description: string;
  reasoningPath?: string[];
  /** Which k-step round produced this test (1-based). */
  step?: number;
}

export interface OptimizationResult {
  originalCode: string;
  optimizedCode: string;
  fragmentsDetected: number;
  improvements: string[];
  originalLineCount: number;
  optimizedLineCount: number;
  reasoningSteps: string[];
}

/** Which code Stage II sees. 'optimized' is the kS-LLM++ design; 'original' is for ablation runs. */
export type StageIISource = 'optimized' | 'original';

/** Real coverage measured by gcov (see server/runner.mjs). */
export interface CoverageMetrics {
  lineCoverage: number;
  branchCoverage: number;
  functionCoverage: number;
  linesTotal: number;
  linesCovered: number;
  branchesTotal: number;
  branchesTaken: number;
  functionsTotal: number;
  functionsCovered: number;
  uncoveredLines: number[];
}

export type RunEnding = 'exit' | 'abort' | 'crash' | 'timeout' | 'output_limit';

export interface ProgramRun {
  stdout: string;
  exitCode: number | null;
  signal: string | null;
  ending: RunEnding;
  timeMs: number;
  truncated: boolean;
}

export interface TestResult {
  id: string;
  step: number | null;
  original: ProgramRun;
  optimized: ProgramRun | null;
  /** Same stdout, exit code and ending on both versions. null = not checked or both timed out. */
  sameBehaviour: boolean | null;
  /** Gemini's predicted output equals the real output of the original program. */
  predictionCorrect: boolean | null;
}

export interface ExecutionReport {
  toolchain: { gcc: string; gcov: string };
  config: { timeoutMs: number; outputLimitBytes: number };
  original: { compiled: true; compileLog: string; coverage: CoverageMetrics };
  optimized: { compiled: boolean; compileLog: string; coverage: CoverageMetrics | null } | null;
  coverageByStep: { step: number; testsSoFar: number; lineCoverage: number; branchCoverage: number }[];
  results: TestResult[];
  summary: {
    tests: number;
    sameBehaviour: number;
    differentBehaviour: number;
    inconclusive: number | null;
    predictionsCorrect: number;
    predictionsChecked: number;
    timeouts: number;
    aborts: number;
    crashes: number;
  };
  executionTimeMs: number;
}

export interface ToolchainStatus {
  ok: boolean;
  gcc: string | null;
  gcov: string | null;
  error: string | null;
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  GENERATING_TESTS = 'GENERATING_TESTS',
  EXECUTING = 'EXECUTING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}
