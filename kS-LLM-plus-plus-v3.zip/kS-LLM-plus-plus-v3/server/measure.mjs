#!/usr/bin/env node
// Re-measure real coverage for a saved run, without the web app.
//
// Usage:
//   node server/measure.mjs <original.c> <tests.json> [--optimized opt.c] [--timeout ms] [--out result.json]
//
// <tests.json> can be:
//   - the "Export JSON" file from the app (its optimized code is used automatically), or
//   - a plain array: [{ "input": "1 2 3", "expectedOutput": "..." }, ...]

import { readFile, writeFile } from 'node:fs/promises';
import { executeSuite } from './runner.mjs';

const args = process.argv.slice(2);
const flag = (name) => {
  const i = args.indexOf(name);
  if (i === -1) return undefined;
  const v = args[i + 1];
  args.splice(i, 2);
  return v;
};
const optimizedPath = flag('--optimized');
const timeoutMs = Number(flag('--timeout')) || undefined;
const outPath = flag('--out');
const [originalPath, testsPath] = args;

if (!originalPath || !testsPath) {
  console.error('Usage: node server/measure.mjs <original.c> <tests.json> [--optimized opt.c] [--timeout ms] [--out result.json]');
  process.exit(1);
}

const originalCode = await readFile(originalPath, 'utf8');
const parsed = JSON.parse(await readFile(testsPath, 'utf8'));
const rawTests = Array.isArray(parsed) ? parsed : parsed.testCases || parsed.tests || [];
const tests = rawTests.map((t, i) => ({
  id: t.id || `t${i + 1}`,
  input: t.input ?? '',
  expectedOutput: t.expectedOutput,
  step: t.step ?? 1,
}));
let optimizedCode;
if (optimizedPath) optimizedCode = await readFile(optimizedPath, 'utf8');
else if (!Array.isArray(parsed) && typeof parsed.optimizedCode === 'string') optimizedCode = parsed.optimizedCode;

const r = await executeSuite({ originalCode, optimizedCode, tests, timeoutMs });
const c = r.original.coverage;
console.log(`Program:          ${originalPath}`);
console.log(`Tests run:        ${r.summary.tests}`);
console.log(`Line coverage:    ${c.lineCoverage}%  (${c.linesCovered}/${c.linesTotal} executable lines)`);
console.log(`Branch coverage:  ${c.branchCoverage}%  (${c.branchesTaken}/${c.branchesTotal} branch outcomes)`);
if (r.optimized) {
  if (!r.optimized.compiled) console.log('Optimized code:   does NOT compile');
  else console.log(`Same behaviour:   ${r.summary.sameBehaviour}/${r.summary.tests} tests (different: ${r.summary.differentBehaviour}, inconclusive: ${r.summary.inconclusive})`);
}
if (r.summary.predictionsChecked) {
  console.log(`Predicted output: ${r.summary.predictionsCorrect}/${r.summary.predictionsChecked} correct`);
}
console.log(`Coverage by step: ${r.coverageByStep.map((s) => `k${s.step}=${s.lineCoverage}/${s.branchCoverage}`).join('  ')}`);
console.log(`Toolchain:        ${r.toolchain.gcc}`);
if (outPath) {
  await writeFile(outPath, JSON.stringify(r, null, 2));
  console.log(`Full result written to ${outPath}`);
}
