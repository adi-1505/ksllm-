// kS-LLM++ execution server.
//
// Runs on your own machine and does what a browser cannot: compile the C
// program with gcc --coverage, run the generated tests, and read real coverage
// from gcov. The web app talks to it through Vite's /api proxy.
//
// Start it with:  npm run server
//
// Security: this server compiles and runs whatever C code it is sent, so it
// only listens on 127.0.0.1 and refuses requests coming from other websites.

import http from 'node:http';
import { executeSuite, checkToolchain } from './runner.mjs';

const PORT = Number(process.env.KSLLM_SERVER_PORT || 3001);
const HOST = '127.0.0.1';
const MAX_BODY = 20 * 1024 * 1024;

function send(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(json) });
  res.end(json);
}

function isAllowedOrigin(origin) {
  if (!origin) return true; // same-origin requests through the Vite proxy, curl, scripts
  try {
    const { hostname } = new URL(origin);
    return hostname === 'localhost' || hostname === '127.0.0.1';
  } catch {
    return false;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new Error('Request too large'));
        req.destroy();
      } else chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

let busy = false;

const server = http.createServer(async (req, res) => {
  if (!isAllowedOrigin(req.headers.origin)) {
    return send(res, 403, { error: 'Requests from other websites are not allowed.' });
  }

  if (req.method === 'GET' && req.url === '/api/health') {
    const tool = await checkToolchain();
    return send(res, tool.ok ? 200 : 500, tool);
  }

  if (req.method === 'POST' && req.url === '/api/execute') {
    if (!String(req.headers['content-type'] || '').includes('application/json')) {
      return send(res, 415, { error: 'Send JSON (Content-Type: application/json).' });
    }
    if (busy) return send(res, 409, { error: 'Another run is in progress. Try again when it finishes.' });
    busy = true;
    try {
      const job = JSON.parse(await readBody(req));
      if (typeof job.originalCode !== 'string' || !Array.isArray(job.tests)) {
        return send(res, 400, { error: 'Expected { originalCode: string, optimizedCode?: string, tests: [] }.' });
      }
      const started = Date.now();
      const report = await executeSuite(job);
      console.log(
        `[execute] ${job.tests.length} tests in ${Date.now() - started} ms -> ` +
          `line ${report.original.coverage.lineCoverage}%, branch ${report.original.coverage.branchCoverage}%`,
      );
      return send(res, 200, report);
    } catch (err) {
      console.error('[execute] failed:', err.message);
      return send(res, 500, { error: err.message });
    } finally {
      busy = false;
    }
  }

  send(res, 404, { error: 'Not found' });
});

const tool = await checkToolchain();
server.listen(PORT, HOST, () => {
  console.log(`kS-LLM++ execution server on http://${HOST}:${PORT}`);
  if (tool.ok) console.log(`  ${tool.gcc}\n  ${tool.gcov}`);
  else console.log(`  WARNING: ${tool.error}`);
});
