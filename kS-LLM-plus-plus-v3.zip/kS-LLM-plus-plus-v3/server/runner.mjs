// kS-LLM++ execution runner.
//
// Compiles the original (and optionally the optimized) C program with
// gcc --coverage, runs every test input through it, records the real output,
// and reads real line/branch coverage from gcov's JSON report.
//
// Coverage definitions (same as gcov's own summary):
//   line coverage   = executable lines run at least once / executable lines
//   branch coverage = branch outcomes taken at least once / branch outcomes
//                     ("Taken at least once" in `gcov -b`)

import { spawn } from 'node:child_process';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HARNESS = path.join(HERE, 'harness.c');

export const DEFAULTS = {
  timeoutMs: 2000,
  outputLimitBytes: 256 * 1024,
  gcc: process.env.KSLLM_GCC || 'gcc',
  gcov: process.env.KSLLM_GCOV || 'gcov',
};

// ---------- small process helpers ----------

function run(cmd, args, { cwd, input = '', timeoutMs = 60000, outputLimitBytes = 8 * 1024 * 1024 } = {}) {
  return new Promise((resolve) => {
    const started = Date.now();
    let child;
    try {
      child = spawn(cmd, args, { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
    } catch (err) {
      resolve({ stdout: '', stderr: String(err), exitCode: null, signal: null, status: 'spawn_error', timeMs: 0 });
      return;
    }
    const out = [];
    const err = [];
    let outBytes = 0;
    let errBytes = 0;
    let status = 'ok';
    let killTimer = null;

    const stop = (why) => {
      if (status !== 'ok') return;
      status = why;
      child.kill('SIGTERM'); // the harness saves gcov data on SIGTERM
      killTimer = setTimeout(() => child.kill('SIGKILL'), 1000);
    };
    const timer = setTimeout(() => stop('timeout'), timeoutMs);

    child.stdout.on('data', (chunk) => {
      outBytes += chunk.length;
      if (outBytes <= outputLimitBytes) out.push(chunk);
      else stop('output_limit');
    });
    child.stderr.on('data', (chunk) => {
      errBytes += chunk.length;
      if (errBytes <= 64 * 1024) err.push(chunk);
    });
    child.on('error', (e) => {
      err.push(Buffer.from(String(e)));
      status = 'spawn_error';
    });
    child.on('close', (exitCode, signal) => {
      clearTimeout(timer);
      if (killTimer) clearTimeout(killTimer);
      resolve({
        stdout: Buffer.concat(out).toString('utf8'),
        stderr: Buffer.concat(err).toString('utf8'),
        exitCode,
        signal,
        status,
        timeMs: Date.now() - started,
        truncated: outBytes > outputLimitBytes,
      });
    });
    child.stdin.on('error', () => {}); // program may exit before reading all input
    child.stdin.end(input);
  });
}

let toolchainCache = null;

export async function checkToolchain() {
  if (toolchainCache) return toolchainCache;
  const gcc = await run(DEFAULTS.gcc, ['--version']);
  const gcov = await run(DEFAULTS.gcov, ['--version']);
  const ver = await run(DEFAULTS.gcc, ['-dumpversion']);
  const ok = gcc.exitCode === 0 && gcov.exitCode === 0;
  toolchainCache = {
    ok,
    gcc: ok ? gcc.stdout.split('\n')[0].trim() : null,
    gcov: ok ? gcov.stdout.split('\n')[0].trim() : null,
    gccMajor: parseInt((ver.stdout || '0').split('.')[0], 10) || 0,
    error: ok ? null : 'gcc and gcov must both be installed and on PATH (on Windows, run the server inside WSL).',
  };
  return toolchainCache;
}

// ---------- compile ----------

function compileFlags(gccMajor) {
  // Benchmarks are old-style C. GCC 14 turned several old warnings into errors,
  // so we relax them; this does not change what the program does.
  const flags = [
    '-O0', '-g', '-w',
    '-Wno-error=implicit-function-declaration',
    '-Wno-error=implicit-int',
    '-Wno-error=int-conversion',
    '-Wno-error=incompatible-pointer-types',
  ];
  if (gccMajor >= 14) flags.push('-fpermissive');
  return flags;
}

async function buildProgram(dir, source, gccMajor) {
  await writeFile(path.join(dir, 'program.c'), source);
  const flags = compileFlags(gccMajor);
  const steps = [
    [DEFAULTS.gcc, ['-c', '--coverage', ...flags, 'program.c', '-o', 'program.o']],
    [DEFAULTS.gcc, ['-c', '-O0', '-w', HARNESS, '-o', 'harness.o']],
    [DEFAULTS.gcc, ['--coverage', 'program.o', 'harness.o', '-o', 'program', '-lm']],
  ];
  let log = '';
  for (const [cmd, args] of steps) {
    const r = await run(cmd, args, { cwd: dir });
    log += r.stderr;
    if (r.exitCode !== 0) return { compiled: false, compileLog: log.slice(0, 8000) };
  }
  return { compiled: true, compileLog: log.slice(0, 8000) };
}

// ---------- coverage ----------

async function readCoverage(dir) {
  if (!existsSync(path.join(dir, 'program.gcda'))) {
    return null; // nothing ran to completion of a dump
  }
  const r = await run(DEFAULTS.gcov, ['--json-format', '--stdout', '-b', '-c', '-o', dir, 'program.c'], { cwd: dir });
  if (r.exitCode !== 0) throw new Error(`gcov failed: ${r.stderr.slice(0, 500)}`);

  // gcov prints one JSON document per source file
  const report = JSON.parse(r.stdout.trim().split('\n').find((l) => l.startsWith('{')));
  const file = report.files.find((f) => path.basename(f.file) === 'program.c');
  if (!file) throw new Error('gcov report did not include program.c');

  const lines = new Map(); // line number -> executed?
  let branchesTotal = 0;
  let branchesTaken = 0;
  for (const ln of file.lines) {
    lines.set(ln.line_number, (lines.get(ln.line_number) || false) || ln.count > 0);
    for (const br of ln.branches || []) {
      if (br.throw) continue;
      branchesTotal += 1;
      if (br.count > 0) branchesTaken += 1;
    }
  }
  const linesTotal = lines.size;
  const linesCovered = [...lines.values()].filter(Boolean).length;
  const uncoveredLines = [...lines.entries()].filter(([, hit]) => !hit).map(([n]) => n).sort((a, b) => a - b);
  const functionsTotal = file.functions.length;
  const functionsCovered = file.functions.filter((f) => f.execution_count > 0).length;
  const pct = (a, b) => (b === 0 ? 0 : Math.round((a / b) * 10000) / 100);

  return {
    lineCoverage: pct(linesCovered, linesTotal),
    branchCoverage: pct(branchesTaken, branchesTotal),
    functionCoverage: pct(functionsCovered, functionsTotal),
    linesTotal,
    linesCovered,
    branchesTotal,
    branchesTaken,
    functionsTotal,
    functionsCovered,
    uncoveredLines: uncoveredLines.slice(0, 1000),
  };
}

function emptyCoverage(linesTotal = 0) {
  return {
    lineCoverage: 0, branchCoverage: 0, functionCoverage: 0,
    linesTotal, linesCovered: 0, branchesTotal: 0, branchesTaken: 0,
    functionsTotal: 0, functionsCovered: 0, uncoveredLines: [],
  };
}

// ---------- comparing outputs ----------

export function normalizeOutput(s) {
  if (s === undefined || s === null) return null;
  return String(s)
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.replace(/[ \t]+$/, ''))
    .join('\n')
    .replace(/\n+$/, '');
}

function sameBehaviour(a, b) {
  if (!a || !b) return null;
  if (a.status === 'timeout' && b.status === 'timeout') return null; // inconclusive
  return (
    a.status === b.status &&
    a.exitCode === b.exitCode &&
    a.signal === b.signal &&
    normalizeOutput(a.stdout) === normalizeOutput(b.stdout)
  );
}

function describeEnding(r) {
  if (r.status === 'timeout') return 'timeout';
  if (r.status === 'output_limit') return 'output_limit';
  if (r.signal === 'SIGABRT') return 'abort';
  if (r.signal) return 'crash';
  return 'exit';
}

// ---------- main entry ----------

/**
 * @param {object} job
 * @param {string} job.originalCode
 * @param {string} [job.optimizedCode]
 * @param {{id:string,input:string,expectedOutput?:string,step?:number}[]} job.tests
 * @param {number} [job.timeoutMs]
 */
export async function executeSuite(job) {
  const started = Date.now();
  const tool = await checkToolchain();
  if (!tool.ok) throw new Error(tool.error);

  const timeoutMs = Math.min(Math.max(Number(job.timeoutMs) || DEFAULTS.timeoutMs, 100), 60000);
  const tests = Array.isArray(job.tests) ? job.tests : [];
  const ordered = [...tests].sort((a, b) => (a.step ?? 0) - (b.step ?? 0));

  const root = await mkdtemp(path.join(tmpdir(), 'ksllm-'));
  const origDir = path.join(root, 'original');
  const optDir = path.join(root, 'optimized');
  try {
    await mkdir(origDir, { recursive: true });
    await mkdir(optDir, { recursive: true });

    const origBuild = await buildProgram(origDir, job.originalCode, tool.gccMajor);
    if (!origBuild.compiled) {
      throw new Error(`The original program does not compile:\n${origBuild.compileLog}`);
    }
    const hasOpt = typeof job.optimizedCode === 'string' && job.optimizedCode.trim() !== '';
    const optBuild = hasOpt ? await buildProgram(optDir, job.optimizedCode, tool.gccMajor) : null;
    const runOpt = !!(optBuild && optBuild.compiled);

    const results = [];
    const coverageByStep = [];

    for (let i = 0; i < ordered.length; i++) {
      const t = ordered[i];
      const input = String(t.input ?? '');
      const [o, p] = await Promise.all([
        run(path.join(origDir, 'program'), [], { cwd: origDir, input, timeoutMs, outputLimitBytes: DEFAULTS.outputLimitBytes }),
        runOpt
          ? run(path.join(optDir, 'program'), [], { cwd: optDir, input, timeoutMs, outputLimitBytes: DEFAULTS.outputLimitBytes })
          : Promise.resolve(null),
      ]);
      const pack = (r) => r && ({
        stdout: r.stdout, exitCode: r.exitCode, signal: r.signal,
        ending: describeEnding(r), timeMs: r.timeMs, truncated: !!r.truncated,
      });
      const predicted = normalizeOutput(t.expectedOutput);
      results.push({
        id: t.id,
        step: t.step ?? null,
        original: pack(o),
        optimized: pack(p),
        sameBehaviour: runOpt ? sameBehaviour(o, p) : null,
        predictionCorrect: predicted === null ? null : predicted === normalizeOutput(o.stdout),
      });

      // coverage after each k-step (counts accumulate in the .gcda file)
      const next = ordered[i + 1];
      const step = t.step ?? 0;
      if (!next || (next.step ?? 0) !== step) {
        const cov = await readCoverage(origDir);
        coverageByStep.push({
          step,
          testsSoFar: i + 1,
          lineCoverage: cov ? cov.lineCoverage : 0,
          branchCoverage: cov ? cov.branchCoverage : 0,
        });
      }
    }

    const originalCoverage = (await readCoverage(origDir)) || emptyCoverage();
    const optimizedCoverage = runOpt ? (await readCoverage(optDir)) || emptyCoverage() : null;

    const judged = results.filter((r) => r.sameBehaviour !== null);
    const predicted = results.filter((r) => r.predictionCorrect !== null);
    const summary = {
      tests: results.length,
      sameBehaviour: judged.filter((r) => r.sameBehaviour).length,
      differentBehaviour: judged.filter((r) => !r.sameBehaviour).length,
      inconclusive: runOpt ? results.length - judged.length : null,
      predictionsCorrect: predicted.filter((r) => r.predictionCorrect).length,
      predictionsChecked: predicted.length,
      timeouts: results.filter((r) => r.original.ending === 'timeout').length,
      aborts: results.filter((r) => r.original.ending === 'abort').length,
      crashes: results.filter((r) => r.original.ending === 'crash').length,
    };

    return {
      toolchain: { gcc: tool.gcc, gcov: tool.gcov },
      config: { timeoutMs, outputLimitBytes: DEFAULTS.outputLimitBytes },
      original: { compiled: true, compileLog: origBuild.compileLog, coverage: originalCoverage },
      optimized: hasOpt
        ? { compiled: optBuild.compiled, compileLog: optBuild.compileLog, coverage: optimizedCoverage }
        : null,
      coverageByStep,
      results,
      summary,
      executionTimeMs: Date.now() - started,
    };
  } finally {
    await rm(root, { recursive: true, force: true });
  }
}

// exported for tests
export const _internal = { readCoverage, buildProgram, run };
