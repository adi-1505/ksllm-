/*
 * kS-LLM++ execution harness.
 *
 * This file is linked into every program under test. It is compiled WITHOUT
 * --coverage, so its own lines never count towards the reported coverage.
 *
 * It does two jobs:
 *
 * 1. Makes gcov data survive abnormal endings.
 *    gcov only writes its counters when a program exits normally. RERS and
 *    PALS benchmarks reach their error states through abort() / assert(0),
 *    and the runner stops slow tests with SIGTERM. Without this handler, the
 *    counts for those runs would be lost and error branches would wrongly show
 *    as "never covered". The handler flushes stdout, calls __gcov_dump(), then
 *    re-raises the signal so the process still ends the same way.
 *
 * 2. Supplies SV-COMP style input functions.
 *    Benchmarks read inputs through __VERIFIER_nondet_*() instead of scanf.
 *    Every call reads the next whitespace-separated token from stdin:
 *      - integer types: the token parsed as a decimal number
 *      - char types:    a number, or else the first character of the token
 *      - _Bool:         0 or 1 (also accepts "true" / "false")
 *    When stdin runs out, every call returns 0.
 *    All definitions are weak, so a program that defines its own version wins.
 */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

extern void __gcov_dump(void);

static void ksllm_on_fatal(int sig) {
    fflush(stdout);
    fflush(stderr);
    __gcov_dump();
    signal(sig, SIG_DFL);
    raise(sig);
}

__attribute__((constructor)) static void ksllm_install(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    signal(SIGABRT, ksllm_on_fatal);
    signal(SIGSEGV, ksllm_on_fatal);
    signal(SIGFPE, ksllm_on_fatal);
    signal(SIGILL, ksllm_on_fatal);
    signal(SIGBUS, ksllm_on_fatal);
    signal(SIGTERM, ksllm_on_fatal);
}

/* Read the next whitespace-separated token from stdin. Returns 0 at EOF. */
static int ksllm_next_token(char *buf, size_t size) {
    if (scanf("%255s", buf) != 1) {
        buf[0] = '\0';
        return 0;
    }
    buf[size - 1] = '\0';
    return 1;
}

static long long ksllm_signed(void) {
    char tok[256];
    if (!ksllm_next_token(tok, sizeof tok)) return 0;
    char *end;
    errno = 0;
    long long v = strtoll(tok, &end, 10);
    if (end == tok) return 0;
    return v;
}

static unsigned long long ksllm_unsigned(void) {
    char tok[256];
    if (!ksllm_next_token(tok, sizeof tok)) return 0;
    char *end;
    errno = 0;
    unsigned long long v = strtoull(tok, &end, 10);
    if (end == tok) return 0;
    return v;
}

static int ksllm_charlike(void) {
    char tok[256];
    if (!ksllm_next_token(tok, sizeof tok)) return 0;
    char *end;
    long v = strtol(tok, &end, 10);
    if (end != tok && *end == '\0') return (int)v;
    return (unsigned char)tok[0];
}

#define KS_WEAK __attribute__((weak))

KS_WEAK int                __VERIFIER_nondet_int(void)       { return (int)ksllm_signed(); }
KS_WEAK unsigned int       __VERIFIER_nondet_uint(void)      { return (unsigned int)ksllm_unsigned(); }
KS_WEAK unsigned int       __VERIFIER_nondet_unsigned(void)  { return (unsigned int)ksllm_unsigned(); }
KS_WEAK long               __VERIFIER_nondet_long(void)      { return (long)ksllm_signed(); }
KS_WEAK unsigned long      __VERIFIER_nondet_ulong(void)     { return (unsigned long)ksllm_unsigned(); }
KS_WEAK long long          __VERIFIER_nondet_longlong(void)  { return ksllm_signed(); }
KS_WEAK unsigned long long __VERIFIER_nondet_ulonglong(void) { return ksllm_unsigned(); }
KS_WEAK short              __VERIFIER_nondet_short(void)     { return (short)ksllm_signed(); }
KS_WEAK unsigned short     __VERIFIER_nondet_ushort(void)    { return (unsigned short)ksllm_unsigned(); }
KS_WEAK char               __VERIFIER_nondet_char(void)      { return (char)ksllm_charlike(); }
KS_WEAK unsigned char      __VERIFIER_nondet_uchar(void)     { return (unsigned char)ksllm_charlike(); }
KS_WEAK float              __VERIFIER_nondet_float(void)     { char t[256]; return ksllm_next_token(t, sizeof t) ? strtof(t, NULL) : 0.0f; }
KS_WEAK double             __VERIFIER_nondet_double(void)    { char t[256]; return ksllm_next_token(t, sizeof t) ? strtod(t, NULL) : 0.0; }
KS_WEAK void *             __VERIFIER_nondet_pointer(void)   { return NULL; }

KS_WEAK _Bool __VERIFIER_nondet_bool(void) {
    char tok[256];
    if (!ksllm_next_token(tok, sizeof tok)) return 0;
    if (strcmp(tok, "true") == 0) return 1;
    if (strcmp(tok, "false") == 0) return 0;
    return strtol(tok, NULL, 10) != 0;
}

/* assume(false) means "this path is not part of the model": end the run quietly. */
KS_WEAK void __VERIFIER_assume(int cond) { if (!cond) exit(0); }

/* Older benchmarks call this without defining it. */
KS_WEAK void __VERIFIER_error(void) {
    fprintf(stderr, "__VERIFIER_error reached\n");
    abort();
}
