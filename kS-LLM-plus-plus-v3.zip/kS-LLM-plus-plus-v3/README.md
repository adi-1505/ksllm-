# kS-LLM++ Testcase Generator (v3.0)

A two-stage pipeline for C programs:

1. **Stage I – Optimizer agent** (Gemini 3 Pro, Tree-of-Thought prompt) refactors the C code to remove redundancy.
2. **Stage II – Test generator agent** (Gemini 3 Flash) reads the **optimized** code and generates tests in k-steps
   (20 per step, until 50 unique tests or 10 steps).
3. **Execution** – every test is compiled and run with `gcc --coverage`, and coverage is **measured with gcov**.

Nothing in this version estimates or simulates coverage. If the execution server is not running, the app says so
instead of showing numbers.

## What gets measured

| Result | How |
| :--- | :--- |
| Line coverage | gcov: executable lines run at least once / executable lines, on the **original** program |
| Branch coverage | gcov "Taken at least once": branch outcomes taken / branch outcomes, on the **original** program |
| Coverage per k-step | gcov after each step's tests (counts accumulate) |
| Same behaviour | each test is run on the original and the optimized program; stdout, exit code and ending are compared |
| Prediction accuracy | Gemini's predicted output vs the real output of the original program |
| LOC reduction | Eq. 1 of the paper, using the line counts of both files |

Coverage is always measured on the original program, so results are comparable with CBMC and kS-LLM.

## Requirements

- Node.js 18 or newer
- `gcc` and `gcov` on your PATH (they come together with GCC)
  - Linux: `sudo apt install gcc`
  - Windows: run everything inside **WSL** (Ubuntu), not in PowerShell
  - macOS: install real GCC (`brew install gcc`), then set `KSLLM_GCC=gcc-14 KSLLM_GCOV=gcov-14`
- A Gemini API key

## Run it

1. `npm install`
2. Put your key in `.env.local`: `GEMINI_API_KEY=your_key_here`
3. Terminal 1, the execution server (compiles and runs the tests):
   `npm run server`
4. Terminal 2, the app:
   `npm run dev`
5. Open http://localhost:3000 and upload a `.c` file.

The sidebar shows whether the execution server is ready. If a run fails because the server was not started,
start it and click **Run Tests Again**. This re-runs only the execution, with no new Gemini calls.

## Ablation: does Stage I help?

The sidebar switch **Stage II generates tests from** has two settings:

- **Optimized code** – the kS-LLM++ design.
- **Original code** – tests come from the original code, as in kS-LLM.

Run the same program once in each mode and compare the coverage. Coverage is measured on the original program in
both modes, so the difference shows the effect of Stage I.

## How inputs reach the program

The test input is sent to the program's stdin. `scanf`, `getchar` and similar functions read it normally.

SV-COMP benchmarks (RERS, PALS) read inputs through `__VERIFIER_nondet_int()` and similar functions instead.
`server/harness.c` supplies these: each call reads the next whitespace-separated token from stdin (integers as
numbers, `char` as a number or a single character, `_Bool` as 0/1). When the input runs out, they return 0.
The Stage II prompt explains this to Gemini.

The harness also makes gcov save its data when a program ends with `abort()` or a failed `assert`, crashes, or is
stopped by the timeout. Without it, those runs would be lost and error branches would look uncovered.
The harness is compiled without coverage, so it never affects the numbers.

## Outputs

- **Export Report** – a Markdown report with the setup, LOC, coverage, coverage per k-step, behaviour check,
  prediction accuracy, and every test with its predicted and actual output.
- **Export JSON** – the same data in machine-readable form, for building tables.

## Re-measuring a saved run (no Gemini calls)

```bash
npm run measure -- program.c RESULTS_program_optimized.json
# or with plain tests:  [{ "input": "1 2 3", "expectedOutput": "..." }, ...]
npm run measure -- program.c tests.json --optimized program_opt.c --timeout 2000 --out result.json
```

## Settings

| Setting | Value | Where |
| :--- | :--- | :--- |
| Optimizer | gemini-3-pro-preview, temperature 0.1, thinking budget 4000 | `services/geminiService.ts` |
| Test generator | gemini-3-flash-preview, temperature 0.5 | `services/geminiService.ts` |
| k-steps | 20 tests per step, min 50 unique tests, max 10 steps | `App.tsx` |
| Timeout per test | 2 s | `App.tsx` |
| Server port | 3001 (change with `KSLLM_SERVER_PORT`) | `server/index.mjs` |

## Files

| File | Purpose |
| :--- | :--- |
| `App.tsx` | Pipeline: Stage I → Stage II (k-steps) → execution, plus reports |
| `services/geminiService.ts` | The two Gemini agents and their prompts |
| `services/executionService.ts` | Calls the local execution server |
| `components/MetricsDashboard.tsx` | Coverage, behaviour check and per-test results |
| `server/index.mjs` | Local HTTP server (127.0.0.1 only) |
| `server/runner.mjs` | Compile, run tests, compare outputs, read gcov |
| `server/harness.c` | Input functions for benchmarks + saving gcov data on abort/crash/timeout |
| `server/measure.mjs` | Command-line re-measurement |

## Security

The execution server compiles and runs whatever C code it receives. It listens only on 127.0.0.1 and rejects
requests from other websites. Only run it on your own machine.

## Known limitations

- Stage I sends the whole file in one prompt; it does not split it into fragments.
- Tree-of-Thought is done inside the prompt (one call per stage), not as a separate search over several calls.
- Coverage is not fed back into the next k-step yet. `uncoveredLines` in the results is there for that next step.
- LLM output varies between runs: repeat each experiment and report the mean and spread.
