import React, { useState, useRef, useEffect } from 'react';
import { UploadCloud, Download, Terminal, Sparkles, FileJson, RefreshCw } from 'lucide-react';
import ChatInterface from './components/ChatInterface';
import CodeViewer from './components/CodeViewer';
import MetricsDashboard from './components/MetricsDashboard';
import { ChatMessage, AppState, OptimizationResult, TestCase, ExecutionReport, StageIISource, ToolchainStatus } from './types';
import { optimizeCCode, generateTestCases, PIPELINE_CONFIG } from './services/geminiService';
import { executeTests, checkExecutionServer } from './services/executionService';

// k-step settings (kept identical to the original kS-LLM++ configuration)
const MIN_TESTS = 50;
const MAX_STEPS = 10;
const BATCH_SIZE = 20;
const TIMEOUT_MS = 2000;

const INITIAL_MESSAGE: ChatMessage = {
  id: 'init',
  role: 'assistant',
  content: "Testcase generator v3.0 online.\n\nPipeline:\n- Stage I: Gemini 3 Pro refactors the C code (Tree-of-Thought prompt)\n- Stage II: Gemini 3 Flash generates tests from the optimized code, up to 10 k-steps, min 50 unique tests\n- Execution: every test is compiled and run with gcc; coverage is measured by gcov\n\nDrop a C file to start.",
  timestamp: Date.now(),
  type: 'text'
};

const SunLogo = () => (
  <svg viewBox="0 0 100 100" className="w-10 h-10 drop-shadow-[0_0_8px_rgba(220,38,38,0.5)]">
    <circle cx="50" cy="50" r="25" fill="#b91c1c" />
    <g fill="none" stroke="#b91c1c" strokeWidth="2" strokeLinecap="round">
      {[...Array(16)].map((_, i) => (
        <path
          key={i}
          d="M50 25 Q60 10 50 0"
          transform={`rotate(${i * 22.5} 50 50)`}
          className="stroke-red-700"
        />
      ))}
    </g>
    <circle cx="50" cy="50" r="25" fill="none" stroke="#ca8a04" strokeWidth="1" />
  </svg>
);

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [messages, setMessages] = useState<ChatMessage[]>([INITIAL_MESSAGE]);
  const [originalCode, setOriginalCode] = useState<string>("");
  const [optimizedResult, setOptimizedResult] = useState<OptimizationResult | null>(null);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [executionReport, setExecutionReport] = useState<ExecutionReport | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [stage2Source, setStage2Source] = useState<StageIISource>('optimized');
  const [runSource, setRunSource] = useState<StageIISource>('optimized');
  const [stepsUsed, setStepsUsed] = useState<number>(0);
  const [toolchain, setToolchain] = useState<ToolchainStatus | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const redundancyCache = useRef<Set<string>>(new Set<string>());

  const isBusy = appState === AppState.ANALYZING || appState === AppState.GENERATING_TESTS || appState === AppState.EXECUTING;

  const refreshToolchain = async () => setToolchain(await checkExecutionServer());
  useEffect(() => { refreshToolchain(); }, []);

  const addMessage = (role: 'assistant' | 'user' | 'system', content: string, type: 'text' | 'loader' | 'result_summary' | 'thought' = 'text', thoughts?: string[]) => {
    setMessages(prev => [...prev, {
      id: Math.random().toString(36),
      role,
      content,
      timestamp: Date.now(),
      type,
      thoughts
    }]);
  };

  const updateLastMessage = (content: string, type: 'text' | 'loader' | 'result_summary' | 'thought' = 'text', thoughts?: string[]) => {
    setMessages(prev => {
      const newArr = [...prev];
      if (newArr.length === 0) return newArr;
      newArr[newArr.length - 1] = { ...newArr[newArr.length - 1], content, type, thoughts };
      return newArr;
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = '';

    setFileName(file.name);
    const text = await file.text();
    setOriginalCode(text);
    setOptimizedResult(null);
    setTestCases([]);
    setExecutionReport(null);
    setStepsUsed(0);
    redundancyCache.current.clear();

    addMessage('user', `Uploaded: ${file.name}`);
    startPipeline(text);
  };

  const getLineCount = (code: string) => code.trim().split('\n').length;

  const summarizeReport = (report: ExecutionReport, testsRun: number) => {
    const c = report.original.coverage;
    const behaviour = !report.optimized
      ? ''
      : report.optimized.compiled
        ? `\n- Same behaviour on optimized code: ${report.summary.sameBehaviour}/${report.summary.tests} tests` +
          (report.summary.differentBehaviour ? ` (${report.summary.differentBehaviour} differ)` : '')
        : '\n- Optimized code does NOT compile (see report)';
    return `Pipeline Complete.\nMeasured with gcov on the original program:\n- Line coverage: ${c.lineCoverage}% (${c.linesCovered}/${c.linesTotal} lines)\n- Branch coverage: ${c.branchCoverage}% (${c.branchesTaken}/${c.branchesTotal} branches)` +
      `${behaviour}\n- Gemini predicted the exact output for ${report.summary.predictionsCorrect}/${report.summary.predictionsChecked} tests\nTests executed: ${testsRun}`;
  };

  const runExecution = async (code: string, optimizedCode: string, tests: TestCase[]) => {
    setAppState(AppState.EXECUTING);
    addMessage('system', 'Execution: compiling with gcc --coverage and running every test on the original and optimized programs...', 'loader');
    const report = await executeTests(code, optimizedCode, tests, TIMEOUT_MS);
    setExecutionReport(report);
    updateLastMessage(summarizeReport(report, tests.length), 'result_summary');
    setAppState(AppState.COMPLETED);
  };

  const startPipeline = async (code: string) => {
    const source = stage2Source;
    setRunSource(source);
    setAppState(AppState.ANALYZING);
    addMessage('system', 'Optimizer Agent: Initiating Tree-of-Thought Optimization...', 'loader');

    try {
      const optResult = await optimizeCCode(code);
      setOptimizedResult(optResult);
      
      const realOrigCount = getLineCount(code);
      const realOptCount = getLineCount(optResult.optimizedCode);

      updateLastMessage(
        `Optimization Complete.\n\nStats:\n- Fragments: ${optResult.fragmentsDetected}\n- Original: ${realOrigCount} lines\n- Optimized: ${realOptCount} lines\n- Reduction: ${Math.max(0, realOrigCount - realOptCount)} lines removed`,
        'text',
        optResult.reasoningSteps
      );

      // Stage II reads the optimized code (the kS-LLM++ design) unless the
      // ablation setting asks for the original code.
      const stage2Code = source === 'optimized' ? optResult.optimizedCode : code;
      
      setAppState(AppState.GENERATING_TESTS);
      addMessage('system', `Test Generator Agent: reading the ${source} code. Step 1/${MAX_STEPS}...`, 'loader');

      let currentStep = 0;
      const allTests: TestCase[] = [];
      const inputsCache: string[] = [];

      while (allTests.length < MIN_TESTS && currentStep < MAX_STEPS) {
        currentStep++;
        updateLastMessage(`Step ${currentStep} (Accumulated: ${allTests.length}): Exploring deep execution paths (ToT)...`, 'loader');
        
        try {
            const newTests = await generateTestCases(stage2Code, inputsCache, BATCH_SIZE, currentStep);
            
            let addedCount = 0;
            newTests.forEach(t => {
              // Normalize input for redundancy check
              const normalized = t.input.trim();
              if (!redundancyCache.current.has(normalized)) {
                redundancyCache.current.add(normalized);
                allTests.push(t);
                inputsCache.push(t.input);
                addedCount++;
              }
            });

            setTestCases([...allTests]);

            if (addedCount > 0) {
               addMessage('assistant', `Step ${currentStep}: Discovered ${addedCount} new unique inputs. Total: ${allTests.length}.`, 'thought', newTests.flatMap(t => t.reasoningPath || []).slice(0, 5));
            } else {
               console.log("No new unique tests found in this batch.");
            }
            
            addMessage('system', `Continuing deep exploration...`, 'loader');

        } catch (err) {
            console.warn(`Step ${currentStep} failed, moving to the next step...`, err);
        }
        
        await new Promise(r => setTimeout(r, 200));
      }

      setStepsUsed(currentStep);
      updateLastMessage(`Search Concluded. Total unique test inputs: ${allTests.length} after ${currentStep} k-steps.`, 'text');
      if (allTests.length === 0) throw new Error('No test cases were generated.');

      await runExecution(code, optResult.optimizedCode, allTests);

    } catch (error) {
      setAppState(AppState.ERROR);
      addMessage('system', `Pipeline Fault: ${error instanceof Error ? error.message : 'Unknown fatal error'}`, 'text');
      refreshToolchain();
    }
  };

  // Re-run only the execution step (e.g. after starting the server), without new Gemini calls.
  const retryExecution = async () => {
    if (!optimizedResult || testCases.length === 0) return;
    try {
      await runExecution(originalCode, optimizedResult.optimizedCode, testCases);
    } catch (error) {
      setAppState(AppState.ERROR);
      addMessage('system', `Pipeline Fault: ${error instanceof Error ? error.message : 'Unknown fatal error'}`, 'text');
    }
    refreshToolchain();
  };

  const sanitizeForTable = (str: string | undefined | null, max = 300) => {
    if (str === undefined || str === null) return '';
    const clipped = str.length > max ? str.slice(0, max) + '…' : str;
    return clipped
      .replace(/\\/g, '\\\\')
      .replace(/\|/g, '\\|')
      .replace(/`/g, "'")
      .replace(/\n/g, '<br/>')
      .replace(/[\x00-\x1F\x7F-\x9F]/g, c => `\\\\x${c.charCodeAt(0).toString(16).padStart(2, '0').toUpperCase()}`);
  };

  const downloadFile = (content: string, name: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const baseName = () => (fileName || 'program').replace(/\.[^/.]+$/, "");

  const describeRun = (r: { ending: string; exitCode: number | null; signal: string | null } | null) => {
    if (!r) return '—';
    if (r.ending === 'exit') return `exit ${r.exitCode}`;
    if (r.ending === 'timeout') return 'timeout';
    if (r.ending === 'output_limit') return 'output limit';
    return `${r.ending} (${r.signal})`;
  };

  const handleDownload = () => {
    if (!optimizedResult || !executionReport || !fileName) return;
    const report = executionReport;
    const timestamp = new Date().toLocaleString();
    const realOrigCount = getLineCount(originalCode);
    const realOptCount = getLineCount(optimizedResult.optimizedCode);
    const locReduction = realOrigCount === 0 ? 0 : ((realOrigCount - realOptCount) / realOrigCount) * 100;
    const oc = report.original.coverage;
    const opt = report.optimized;
    const pc = opt?.coverage ?? null;
    const byId = new Map(report.results.map(r => [r.id, r]));

    const optRow = !opt
      ? '| **Optimized** | not run | | | | |'
      : !opt.compiled || !pc
        ? '| **Optimized** | does not compile | | | | |'
        : `| **Optimized** | ${pc.lineCoverage}% | ${pc.branchCoverage}% | ${pc.functionCoverage}% | ${pc.linesCovered}/${pc.linesTotal} | ${pc.branchesTaken}/${pc.branchesTotal} |`;

    const behaviourSection = !opt
      ? 'Not checked (no optimized code).'
      : !opt.compiled
        ? `The optimized code **does not compile**, so its behaviour could not be checked.\n\n\`\`\`\n${opt.compileLog}\n\`\`\``
        : `| Result | Tests |\n| :--- | :---: |\n| Same output, exit code and ending | ${report.summary.sameBehaviour} |\n| **Different** | ${report.summary.differentBehaviour} |\n| Inconclusive (both timed out) | ${report.summary.inconclusive ?? 0} |`;

    const stepRows = report.coverageByStep
      .map(s => `| k=${s.step} | ${s.testsSoFar} | ${s.lineCoverage}% | ${s.branchCoverage}% |`)
      .join('\n');

    const testsTable = testCases.map((t, i) => {
      const r = byId.get(t.id);
      const pred = r?.predictionCorrect === null || r?.predictionCorrect === undefined ? '' : r.predictionCorrect ? ' ✓' : ' ✗';
      const same = r?.sameBehaviour === null || r?.sameBehaviour === undefined ? '—' : r.sameBehaviour ? 'same' : '**different**';
      return `| ${i + 1} | ${t.step ?? ''} | ${t.category.toUpperCase()} | \`${sanitizeForTable(t.input)}\` | \`${sanitizeForTable(t.expectedOutput?.replace(/\n+$/, ''))}\`${pred} | \`${sanitizeForTable(r?.original.stdout?.replace(/\n+$/, ''))}\` | ${describeRun(r?.original ?? null)} | ${same} | ${t.description.replace(/\|/g, '\\|')} |`;
    }).join('\n');

    const markdownContent = `
# C Optimization & Test Generation Report
**Target Module:** \`${fileName}\`
**Report Timestamp:** ${timestamp}

All coverage numbers below were measured by compiling the program with \`gcc --coverage\`, running every generated test, and reading the results with gcov. Nothing is estimated.

---

## Setup
| Setting | Value |
| :--- | :--- |
| **Stage II generated tests from** | ${runSource === 'optimized' ? 'optimized code (kS-LLM++ design)' : 'original code (ablation run)'} |
| **Optimizer agent** | ${PIPELINE_CONFIG.optimizerModel}, temperature ${PIPELINE_CONFIG.optimizerTemperature}, thinking budget ${PIPELINE_CONFIG.optimizerThinkingBudget} |
| **Test generator agent** | ${PIPELINE_CONFIG.generatorModel}, temperature ${PIPELINE_CONFIG.generatorTemperature} |
| **k-step settings** | ${BATCH_SIZE} tests per step, stop at ${MIN_TESTS} unique tests or ${MAX_STEPS} steps |
| **k-steps used** | ${stepsUsed} |
| **Compiler** | ${report.toolchain.gcc} |
| **Coverage tool** | ${report.toolchain.gcov} |
| **Timeout per test** | ${report.config.timeoutMs} ms |

---

## Stage I: Code Size
| Metric | Original | Optimized |
| :--- | :---: | :---: |
| **Lines of code (all lines)** | ${realOrigCount} | ${realOptCount} |
| **Executable lines (gcov)** | ${oc.linesTotal} | ${pc ? pc.linesTotal : '—'} |
| **Branch outcomes (gcov)** | ${oc.branchesTotal} | ${pc ? pc.branchesTotal : '—'} |

- **LOC reduction (Eq. 1):** ${locReduction.toFixed(2)}%
- **Fragments reported by the optimizer:** ${optimizedResult.fragmentsDetected}

---

## Coverage (measured with gcov)
The **Original** row is the main result: the original program run with every generated test.

| Program | Line | Branch | Function | Lines covered | Branches taken |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Original** | ${oc.lineCoverage}% | ${oc.branchCoverage}% | ${oc.functionCoverage}% | ${oc.linesCovered}/${oc.linesTotal} | ${oc.branchesTaken}/${oc.branchesTotal} |
${optRow}

### Coverage after each k-step (original program)
| Step | Tests so far | Line | Branch |
| :---: | :---: | :---: | :---: |
${stepRows}

---

## Behaviour Check: Original vs Optimized
Every test was run on both programs and their output, exit code and ending were compared.

${behaviourSection}

## Gemini's Predicted Outputs
Gemini predicted the exact output for **${report.summary.predictionsCorrect} of ${report.summary.predictionsChecked}** tests (compared with the real output of the original program, ignoring trailing spaces).

## How the Tests Ended (original program)
| Normal exit | Abort / assert | Crash | Timeout |
| :---: | :---: | :---: | :---: |
| ${report.summary.tests - report.summary.aborts - report.summary.crashes - report.summary.timeouts} | ${report.summary.aborts} | ${report.summary.crashes} | ${report.summary.timeouts} |

---

## 🧠 Tree-of-Thought (ToT) Optimization Strategy
The optimizer agent reported these reasoning steps:
${optimizedResult.reasoningSteps.map((step, i) => `- **Step ${i + 1}:** ${step}`).join('\n')}

---

## 🧪 Test Suite (${testCases.length} Cases)
✓ / ✗ shows whether Gemini's predicted output matched the real output.

| # | k-step | Category | Input (stdin) | Predicted output | Actual output (original) | Ending | Optimized | Description |
| :--- | :---: | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
${testsTable}

---

## 📝 Optimized C Source Code
\`\`\`c
${optimizedResult.optimizedCode}
\`\`\`

---
*Generated by Testcase generator v3.0 (Gemini + gcc/gcov)*
`.trim();

    downloadFile(markdownContent, `REPORT_${baseName()}_v3.md`, 'text/markdown');
  };

  // Machine-readable export. Can be re-measured later with: node server/measure.mjs <file.c> <this.json>
  const handleExportJson = () => {
    if (!optimizedResult || !executionReport || !fileName) return;
    const realOrigCount = getLineCount(originalCode);
    const realOptCount = getLineCount(optimizedResult.optimizedCode);
    const data = {
      file: fileName,
      exportedAt: new Date().toISOString(),
      setup: {
        stage2Source: runSource,
        ...PIPELINE_CONFIG,
        batchSize: BATCH_SIZE,
        minTests: MIN_TESTS,
        maxSteps: MAX_STEPS,
        stepsUsed,
        timeoutMs: executionReport.config.timeoutMs,
        toolchain: executionReport.toolchain,
      },
      loc: {
        original: realOrigCount,
        optimized: realOptCount,
        reductionPercent: realOrigCount === 0 ? 0 : ((realOrigCount - realOptCount) / realOrigCount) * 100,
        fragmentsDetected: optimizedResult.fragmentsDetected,
      },
      optimizedCode: optimizedResult.optimizedCode,
      improvements: optimizedResult.improvements,
      reasoningSteps: optimizedResult.reasoningSteps,
      testCases,
      execution: executionReport,
    };
    downloadFile(JSON.stringify(data, null, 2), `RESULTS_${baseName()}_${runSource}.json`, 'application/json');
  };

  return (
    <div className="flex h-screen w-full bg-black text-white font-sans overflow-hidden">
      {/* Sidebar */}
      <div className="w-80 flex-shrink-0 bg-zinc-950 border-r border-zinc-800 flex flex-col justify-between gap-6 p-6 z-20 overflow-y-auto min-h-0">
        <div>
          <div className="flex items-center space-x-3 mb-8">
            <SunLogo />
            <div className="flex flex-col">
              <span className="font-bold text-xl leading-none tracking-tight">Testcase generator</span>
              <span className="text-[10px] font-bold text-zinc-500 tracking-widest uppercase mt-1">C-Optimization Engine</span>
            </div>
          </div>

          <div className="space-y-4">
             <div 
               className="group relative border-2 border-dashed border-zinc-800 bg-zinc-900/50 rounded-2xl p-6 hover:border-red-600 hover:bg-zinc-900 transition-all cursor-pointer flex flex-col items-center text-center overflow-hidden"
               onClick={() => !isBusy && fileInputRef.current?.click()}
             >
                <UploadCloud className="w-10 h-10 text-zinc-600 group-hover:text-red-500 mb-3 transition-colors relative z-10" />
                <span className="text-sm font-bold text-zinc-400 group-hover:text-white relative z-10">Upload Source</span>
                <input type="file" accept=".c" className="hidden" ref={fileInputRef} onChange={handleFileUpload} disabled={isBusy} />
             </div>

             <div className="p-4 bg-zinc-900 rounded-xl border border-zinc-800 shadow-sm space-y-3">
               <div className="flex items-center space-x-2 pb-2 border-b border-zinc-800">
                 <Terminal className="w-3 h-3 text-red-500" />
                 <span className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Configuration</span>
               </div>
               {[
                 { l: 'Engine', v: 'Gemini 3 Pro/Flash' },
                 { l: 'Steps', v: `Dynamic (Max ${MAX_STEPS})` },
                 { l: 'Min Tests', v: String(MIN_TESTS) },
                 { l: 'Coverage', v: 'gcov (measured)' },
                 { l: 'Timeout', v: `${TIMEOUT_MS / 1000} s per test` }
               ].map((item, i) => (
                 <div key={i} className="flex justify-between text-[12px]">
                   <span className="text-zinc-500 font-medium">{item.l}</span>
                   <span className="text-white font-bold">{item.v}</span>
                 </div>
               ))}

               <div className="pt-2 border-t border-zinc-800">
                 <span className="text-[12px] text-zinc-500 font-medium">Stage II generates tests from</span>
                 <div className="mt-2 grid grid-cols-2 gap-1 bg-black rounded-lg p-1 border border-zinc-800" role="radiogroup" aria-label="Code used for test generation">
                   {([
                     { key: 'optimized', label: 'Optimized code' },
                     { key: 'original', label: 'Original code' }
                   ] as { key: StageIISource; label: string }[]).map(opt => (
                     <button
                       key={opt.key}
                       role="radio"
                       aria-checked={stage2Source === opt.key}
                       disabled={isBusy}
                       onClick={() => setStage2Source(opt.key)}
                       className={`text-[11px] font-bold py-1.5 rounded-md transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600 disabled:opacity-50 ${
                         stage2Source === opt.key ? 'bg-red-700 text-white' : 'text-zinc-400 hover:text-white'
                       }`}
                     >
                       {opt.label}
                     </button>
                   ))}
                 </div>
                 <p className="text-[10px] text-zinc-600 mt-2 leading-snug">
                   {stage2Source === 'optimized'
                     ? 'kS-LLM++ design. Coverage is still measured on the original program.'
                     : 'Ablation run: tests come from the original code, as in kS-LLM.'}
                 </p>
               </div>
             </div>

             <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800 text-[11px]">
               <div className="flex items-center justify-between">
                 <div className="flex items-center space-x-2 min-w-0">
                   <span className={`h-2 w-2 rounded-full flex-shrink-0 ${toolchain === null ? 'bg-zinc-600' : toolchain.ok ? 'bg-green-500' : 'bg-red-500'}`} />
                   <span className="font-bold text-zinc-300 truncate">
                     {toolchain === null ? 'Checking execution server…' : toolchain.ok ? 'Execution server ready' : 'Execution server offline'}
                   </span>
                 </div>
                 <button onClick={refreshToolchain} aria-label="Check execution server again" className="text-zinc-500 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600 rounded">
                   <RefreshCw className="w-3 h-3" />
                 </button>
               </div>
               <p className="text-zinc-600 mt-1 leading-snug break-words">
                 {toolchain?.ok ? toolchain.gcc : toolchain?.error ?? ''}
               </p>
             </div>
          </div>
        </div>

        <div className="space-y-3">
          {appState === AppState.COMPLETED && (
             <>
               <button 
                 onClick={handleDownload}
                 className="w-full flex items-center justify-center space-x-2 bg-red-700 hover:bg-red-800 text-white py-3 rounded-xl transition-all shadow-lg shadow-red-900/20 font-bold text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
               >
                 <Download className="w-4 h-4" />
                 <span>Export Report</span>
               </button>
               <button 
                 onClick={handleExportJson}
                 className="w-full flex items-center justify-center space-x-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white py-2.5 rounded-xl transition-all font-bold text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
               >
                 <FileJson className="w-4 h-4" />
                 <span>Export JSON</span>
               </button>
             </>
          )}
          {appState === AppState.ERROR && optimizedResult && testCases.length > 0 && (
             <button 
               onClick={retryExecution}
               className="w-full flex items-center justify-center space-x-2 bg-zinc-900 hover:bg-zinc-800 border border-red-800 text-white py-3 rounded-xl transition-all font-bold text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
             >
               <RefreshCw className="w-4 h-4" />
               <span>Run Tests Again</span>
             </button>
          )}
          <div className="text-[10px] text-zinc-600 font-bold text-center flex items-center justify-center space-x-1">
            <Sparkles className="w-2 h-2" />
            <span>POWERED BY GOOGLE GENAI</span>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <header className="h-16 bg-black border-b border-zinc-800 flex-shrink-0 flex items-center px-8 justify-between z-10">
           <div className="flex items-center space-x-6">
             <div className="flex items-center space-x-2">
                <div className={`h-2.5 w-2.5 rounded-full ring-4 ring-offset-2 ring-offset-black ${
                    appState === AppState.IDLE ? 'bg-zinc-700 ring-zinc-900' : 
                    appState === AppState.ERROR ? 'bg-red-500 ring-red-900/50' :
                    appState === AppState.COMPLETED ? 'bg-green-500 ring-green-900/50' : 'bg-red-600 ring-red-900/50 animate-pulse'
                }`} />
                <span className="text-xs font-bold text-zinc-300 uppercase tracking-widest">
                  {appState.replace('_', ' ')}
                </span>
             </div>
           </div>
           {fileName && (
             <div className="flex items-center space-x-2 text-zinc-200 bg-zinc-900 border border-zinc-800 px-4 py-1.5 rounded-full font-mono text-xs font-bold">
               <Terminal className="w-3 h-3 text-red-500" />
               <span>{fileName}</span>
             </div>
           )}
        </header>

        <main className="flex-1 p-6 grid grid-cols-12 gap-6 overflow-hidden min-h-0">
          <div className="col-span-12 lg:col-span-4 h-full flex flex-col overflow-hidden">
            <ChatInterface messages={messages} />
          </div>

          <div className="col-span-12 lg:col-span-8 flex flex-col gap-6 h-full overflow-hidden min-h-0">
            <div className="flex-1 min-h-[300px] overflow-hidden">
               <CodeViewer 
                 originalCode={originalCode} 
                 optimizedCode={optimizedResult?.optimizedCode || ''} 
               />
            </div>
            <div className="flex-1 min-h-[300px] overflow-hidden">
               <MetricsDashboard report={executionReport} testCases={testCases} stepsUsed={stepsUsed} isExecuting={appState === AppState.EXECUTING} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;